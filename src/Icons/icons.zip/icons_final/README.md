# Iconos extraídos de index.html

Se encontraron **44 SVG inline**, de los cuales **17 son únicos** (el resto son repeticiones en distintos menús/secciones).

Todos siguen el estilo **Lucide / Feather**: trazo de 2px, esquinas redondeadas, `viewBox 0 0 24 24`. 
Los archivos están **normalizados**: con `xmlns`, `fill=none`, `stroke=currentColor`, `stroke-width=2`, etc., listos para usar en cualquier proyecto.

## Listado

| Archivo | Módulo en la app original | Forma | Repeticiones |
|---------|---------------------------|-------|--------------|
| `activity.svg` | Chat Farmacológico / Pulso | activity | 2× |
| `book.svg` | Glosario / Libro | book | 3× |
| `book-open.svg` | Atlas Farmacológico | book-open | 4× |
| `calculator.svg` | Calculadora de Dosis | calculator | 3× |
| `check-square.svg` | Quiz / Comprobado | check-square | 3× |
| `droplet.svg` | Diluciones / Gota | droplet | 3× |
| `file-edit.svg` | Receta Veterinaria | file-edit | 2× |
| `file-text.svg` | Resumen / Documento | file-text | 4× |
| `flask-conical.svg` | Diluciones IV | flask-conical | 3× |
| `graduation-cap.svg` | Aviso Académico | graduation-cap | 1× |
| `info.svg` | Acerca de | info | 3× |
| `monitor.svg` | Tecnologías Web | monitor | 1× |
| `scale.svg` | Comparador / Balanza | scale | 3× |
| `search.svg` | Buscar / Consultar IA | search | 3× |
| `sparkles.svg` | Tecnología IA | sparkles | 1× |
| `syringe.svg` | Vacunas y Recordatorios | syringe | 3× |
| `zap.svg` | Interacciones / Rayo | zap | 2× |

## Uso en React

```jsx
// Opción A: importar como componente con vite-plugin-svgr o @svgr/webpack
import { ReactComponent as BookOpenIcon } from './icons/book-open.svg';

function Sidebar() {
  return <BookOpenIcon className="w-6 h-6 text-blue-600" />;
}
```

```jsx
// Opción B: importar como URL e insertar en <img>
import bookOpen from './icons/book-open.svg';
<img src={bookOpen} alt="Atlas" width={24} height={24} />
```

## Uso en Vue 3

```vue
<script setup>
import BookOpenIcon from './icons/book-open.svg?component'  // vite-svg-loader
</script>
<template><BookOpenIcon class="icon" /></template>
```

## Color

Los SVG usan `stroke="currentColor"`, así que se pintan con `color` del CSS:
```css
.icon { color: #003087; width: 24px; height: 24px; }
```